// @todo rename
export interface Notice {
  response: boolean;
  notice: string;
}
